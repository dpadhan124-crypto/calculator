/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  FileCode, 
  Folder, 
  Play, 
  Save, 
  Plus, 
  Trash2, 
  ChevronRight, 
  ChevronDown, 
  Search, 
  Settings, 
  Cpu, 
  Menu, 
  X,
  FilePlus,
  FolderPlus,
  Download,
  Upload,
  Monitor,
  Smartphone,
  Sparkles,
  Send,
  Code2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import CodeMirror from '@uiw/react-codemirror';
import { javascript } from '@codemirror/lang-javascript';
import { html } from '@codemirror/lang-html';
import { css } from '@codemirror/lang-css';
import { oneDark } from '@codemirror/theme-one-dark';
import { GoogleGenAI } from "@google/genai";
import { cn } from './lib/utils';

// --- Types ---

interface FileNode {
  id: string;
  name: string;
  type: 'file' | 'folder';
  content?: string;
  parentId: string | null;
  handle?: FileSystemFileHandle | FileSystemDirectoryHandle;
}

interface Tab {
  fileId: string;
}

// --- AI Service ---

const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });
const model = (genAI as any).getGenerativeModel({ model: "gemini-1.5-flash" });

// --- Components ---

export default function App() {
  const [files, setFiles] = useState<FileNode[]>([
    { id: 'root-index', name: 'index.html', type: 'file', content: '<h1>Hello DevCanvas</h1>\n<p>Start coding here...</p>', parentId: null },
    { id: 'root-style', name: 'style.css', type: 'file', content: 'body {\n  background: #0f172a;\n  color: white;\n  font-family: sans-serif;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  height: 100vh;\n  margin: 0;\n}', parentId: null },
  ]);
  const [activeFileId, setActiveFileId] = useState<string | null>('root-index');
  const [tabs, setTabs] = useState<Tab[]>([{ fileId: 'root-index' }, { fileId: 'root-style' }]);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [isAiOpen, setIsAiOpen] = useState(false);
  const [aiInput, setAiInput] = useState("");
  const [aiMessages, setAiMessages] = useState<{ role: 'user' | 'ai', text: string }[]>([]);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string>("");

  const activeFile = files.find(f => f.id === activeFileId);

  // --- File System Handlers ---

  const openDirectory = async () => {
    try {
      // @ts-ignore - File System Access API
      const directoryHandle = await window.showDirectoryPicker();
      const newFiles: FileNode[] = [];
      
      async function scan(handle: FileSystemDirectoryHandle, parentId: string | null) {
        // @ts-ignore
        for await (const entry of (handle as any).values()) {
          const id = crypto.randomUUID();
          if (entry.kind === 'file') {
            const file = await entry.getFile();
            const content = await file.text();
            newFiles.push({ id, name: entry.name, type: 'file', content, parentId, handle: entry });
          } else {
            newFiles.push({ id, name: entry.name, type: 'folder', parentId, handle: entry });
            await scan(entry, id);
          }
        }
      }
      
      await scan(directoryHandle, null);
      setFiles(newFiles);
      if (newFiles.length > 0) {
        const firstFile = newFiles.find(f => f.type === 'file');
        if (firstFile) {
          setActiveFileId(firstFile.id);
          setTabs([{ fileId: firstFile.id }]);
        }
      }
    } catch (err) {
      console.error("Directory access failed:", err);
    }
  };

  const saveFile = async () => {
    if (!activeFile || !activeFile.handle || activeFile.type !== 'file') return;
    try {
      const handle = activeFile.handle as FileSystemFileHandle;
      // @ts-ignore
      const writable = await handle.createWritable();
      await writable.write(activeFile.content || "");
      await writable.close();
      alert("File saved successfully!");
    } catch (err) {
      console.error("Save failed:", err);
    }
  };

  // --- Editor Handlers ---

  const handleCodeChange = (value: string) => {
    if (!activeFileId) return;
    setFiles(prev => prev.map(f => f.id === activeFileId ? { ...f, content: value } : f));
  };

  const getLanguage = (filename: string) => {
    if (filename.endsWith('.js') || filename.endsWith('.ts') || filename.endsWith('.tsx')) return [javascript({ jsx: true, typescript: true })];
    if (filename.endsWith('.html')) return [html()];
    if (filename.endsWith('.css')) return [css()];
    return [];
  };

  // --- Preview Logic ---

  const runProject = useCallback(() => {
    const indexFile = files.find(f => f.name === 'index.html');
    if (!indexFile) return;

    let htmlContent = indexFile.content || "";
    
    // Simple injection of CSS and JS from other files
    files.forEach(f => {
      if (f.name.endsWith('.css')) {
        htmlContent = htmlContent.replace(
          new RegExp(`<link.*?href=["']${f.name}["'].*?>`, 'g'),
          `<style>${f.content}</style>`
        );
      }
      if (f.name.endsWith('.js')) {
        htmlContent = htmlContent.replace(
          new RegExp(`<script.*?src=["']${f.name}["'].*?><\/script>`, 'g'),
          `<script>${f.content}<\/script>`
        );
      }
    });

    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    setPreviewUrl(url);
    setIsPreviewOpen(true);
  }, [files]);

  // --- AI Handlers ---

  const handleAiSubmit = async () => {
    if (!aiInput.trim()) return;
    const userMsg = aiInput;
    setAiMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setAiInput("");
    setIsAiLoading(true);

    try {
      const context = `Current file: ${activeFile?.name}\nContent:\n${activeFile?.content}\n\nUser request: ${userMsg}`;
      const result = await model.generateContent(context);
      const response = await result.response;
      const text = response.text();
      setAiMessages(prev => [...prev, { role: 'ai', text }]);
    } catch (err) {
      setAiMessages(prev => [...prev, { role: 'ai', text: "Sorry, I encountered an error. Please check your API key." }]);
    } finally {
      setIsAiLoading(false);
    }
  };

  // --- Render Helpers ---

  const renderFileTree = (parentId: string | null, depth = 0) => {
    return files
      .filter(f => f.parentId === parentId)
      .map(file => (
        <div key={file.id}>
          <div 
            className={cn(
              "flex items-center gap-2 px-4 py-1.5 cursor-pointer hover:bg-slate-800 transition-colors text-sm",
              activeFileId === file.id && "bg-slate-800 text-blue-400 border-l-2 border-blue-400"
            )}
            style={{ paddingLeft: `${depth * 12 + 16}px` }}
            onClick={() => {
              if (file.type === 'file') {
                setActiveFileId(file.id);
                if (!tabs.find(t => t.fileId === file.id)) {
                  setTabs(prev => [...prev, { fileId: file.id }]);
                }
              }
            }}
          >
            {file.type === 'folder' ? <Folder className="w-4 h-4 text-amber-400" /> : <FileCode className="w-4 h-4 text-blue-400" />}
            <span className="truncate">{file.name}</span>
          </div>
          {file.type === 'folder' && renderFileTree(file.id, depth + 1)}
        </div>
      ));
  };

  return (
    <div className="flex flex-col h-screen bg-slate-950 text-slate-200 overflow-hidden font-sans">
      {/* --- Header --- */}
      <header className="h-12 border-b border-slate-800 flex items-center justify-between px-4 bg-slate-900/50 backdrop-blur-md z-50">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-1.5 hover:bg-slate-800 rounded-md transition-colors"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2 font-bold text-slate-100 tracking-tight">
            <Code2 className="w-6 h-6 text-blue-500" />
            <span>DevCanvas <span className="text-blue-500">IDE</span></span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button 
            onClick={runProject}
            className="flex items-center gap-2 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-md text-sm font-medium transition-all active:scale-95 shadow-lg shadow-emerald-900/20"
          >
            <Play className="w-4 h-4 fill-current" />
            <span className="hidden sm:inline">Run</span>
          </button>
          <button 
            onClick={saveFile}
            className="p-2 hover:bg-slate-800 rounded-md transition-colors text-slate-400 hover:text-slate-100"
            title="Save to Device"
          >
            <Save className="w-5 h-5" />
          </button>
          <button 
            onClick={() => setIsAiOpen(!isAiOpen)}
            className={cn(
              "p-2 rounded-md transition-all",
              isAiOpen ? "bg-blue-600 text-white" : "hover:bg-slate-800 text-slate-400"
            )}
          >
            <Sparkles className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* --- Main Content --- */}
      <main className="flex flex-1 overflow-hidden relative">
        {/* --- Sidebar --- */}
        <AnimatePresence mode="wait">
          {isSidebarOpen && (
            <motion.aside 
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 260, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              className="border-r border-slate-800 bg-slate-900/30 flex flex-col z-40"
            >
              <div className="p-4 flex items-center justify-between border-b border-slate-800/50">
                <span className="text-xs font-bold uppercase tracking-widest text-slate-500">Explorer</span>
                <div className="flex gap-2">
                  <button onClick={openDirectory} title="Open Folder from Device" className="p-1 hover:bg-slate-800 rounded text-slate-400">
                    <FolderPlus className="w-4 h-4" />
                  </button>
                  <button className="p-1 hover:bg-slate-800 rounded text-slate-400">
                    <FilePlus className="w-4 h-4" />
                  </button>
                </div>
              </div>
              <div className="flex-1 overflow-y-auto py-2 no-scrollbar">
                {renderFileTree(null)}
              </div>
            </motion.aside>
          )}
        </AnimatePresence>

        {/* --- Editor Area --- */}
        <div className="flex-1 flex flex-col min-w-0 bg-slate-950">
          {/* --- Tabs --- */}
          <div className="h-10 border-b border-slate-800 flex items-center bg-slate-900/20 overflow-x-auto no-scrollbar">
            {tabs.map(tab => {
              const file = files.find(f => f.id === tab.fileId);
              if (!file) return null;
              return (
                <div 
                  key={tab.fileId}
                  className={cn(
                    "h-full flex items-center gap-2 px-4 border-r border-slate-800 cursor-pointer text-sm transition-colors whitespace-nowrap",
                    activeFileId === tab.fileId ? "bg-slate-950 text-blue-400 border-t-2 border-t-blue-500" : "hover:bg-slate-900 text-slate-500"
                  )}
                  onClick={() => setActiveFileId(tab.fileId)}
                >
                  <FileCode className="w-3.5 h-3.5" />
                  <span>{file.name}</span>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      setTabs(prev => prev.filter(t => t.fileId !== tab.fileId));
                      if (activeFileId === tab.fileId) setActiveFileId(null);
                    }}
                    className="ml-2 p-0.5 hover:bg-slate-800 rounded"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              );
            })}
          </div>

          {/* --- Code Editor --- */}
          <div className="flex-1 overflow-hidden relative">
            {activeFileId ? (
              <CodeMirror
                value={activeFile?.content || ""}
                height="100%"
                theme={oneDark}
                extensions={getLanguage(activeFile?.name || "")}
                onChange={handleCodeChange}
                className="text-base h-full"
              />
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-slate-600 gap-4">
                <Code2 className="w-16 h-16 opacity-10" />
                <p>Select a file to start editing</p>
              </div>
            )}
          </div>
        </div>

        {/* --- AI Assistant Panel --- */}
        <AnimatePresence>
          {isAiOpen && (
            <motion.div 
              initial={{ x: 400 }}
              animate={{ x: 0 }}
              exit={{ x: 400 }}
              className="absolute right-0 top-0 bottom-0 w-full sm:w-80 bg-slate-900 border-l border-slate-800 flex flex-col z-50 shadow-2xl"
            >
              <div className="p-4 border-b border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2 font-bold text-blue-400">
                  <Sparkles className="w-4 h-4" />
                  <span>AI Assistant</span>
                </div>
                <button onClick={() => setIsAiOpen(false)} className="p-1 hover:bg-slate-800 rounded">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
                {aiMessages.map((msg, i) => (
                  <div key={i} className={cn(
                    "p-3 rounded-lg text-sm max-w-[85%]",
                    msg.role === 'user' ? "bg-blue-600 ml-auto" : "bg-slate-800 mr-auto"
                  )}>
                    {msg.text}
                  </div>
                ))}
                {isAiLoading && (
                  <div className="bg-slate-800 p-3 rounded-lg text-sm mr-auto animate-pulse">
                    Thinking...
                  </div>
                )}
              </div>
              <div className="p-4 border-t border-slate-800">
                <div className="relative">
                  <textarea 
                    value={aiInput}
                    onChange={(e) => setAiInput(e.target.value)}
                    placeholder="Ask AI for help..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 pr-10 text-sm focus:outline-none focus:border-blue-500 resize-none h-20"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleAiSubmit();
                      }
                    }}
                  />
                  <button 
                    onClick={handleAiSubmit}
                    disabled={isAiLoading}
                    className="absolute right-2 bottom-2 p-1.5 bg-blue-600 hover:bg-blue-500 rounded-md transition-colors disabled:opacity-50"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* --- Preview Panel --- */}
        <AnimatePresence>
          {isPreviewOpen && (
            <motion.div 
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="absolute inset-0 bg-white z-[60] flex flex-col"
            >
              <div className="h-12 bg-slate-900 border-b border-slate-800 flex items-center justify-between px-4">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2 text-slate-400 text-sm">
                    <Monitor className="w-4 h-4" />
                    <span>Preview</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button className="p-2 hover:bg-slate-800 rounded text-slate-400" title="Mobile View">
                    <Smartphone className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => setIsPreviewOpen(false)}
                    className="p-2 hover:bg-slate-800 rounded text-slate-400 hover:text-white"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>
              <iframe 
                src={previewUrl}
                className="flex-1 w-full border-none bg-white"
                title="Preview"
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* --- Footer / Status Bar --- */}
      <footer className="h-6 bg-blue-600 flex items-center px-4 justify-between text-[10px] font-bold uppercase tracking-widest text-blue-100">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1">
            <Cpu className="w-3 h-3" />
            <span>System Ready</span>
          </div>
          <div className="flex items-center gap-1">
            <Download className="w-3 h-3" />
            <span>Sync Active</span>
          </div>
        </div>
        <div>
          {activeFile?.name || "No file selected"}
        </div>
      </footer>
    </div>
  );
}
